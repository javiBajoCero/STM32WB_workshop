/* USER CODE BEGIN */
#ifndef BLUETOOTH_LOGO_H
#define BLUETOOTH_LOGO_H

/* C++ detection */
#ifdef __cplusplus
extern C {
#endif

#define BLUETOOTH_LOGO_WIDTH  22
#define BLUETOOTH_LOGO_HEIGHT 32

extern const long int bluetooth_logo[];

/* C++ detection */
#ifdef __cplusplus
}
#endif

#endif
/* USER CODE END */
